SELECT[Patient_ID]
      ,[Gender]
      ,[Age]
      ,[FirstName]
      ,[LastName]
      ,[BloodType]
      ,[State]
      ,[City]
      ,[Country]
      ,[MedicalHistory]
      ,[MaritalStatus]
  FROM [Healthcare].[dbo].[Patient]


  
  ----3. Data Consistency Check (A)


  SELECT v.Visit_ID, v.Patient_ID, p.Patient_ID
FROM Visit v
LEFT JOIN Patient p ON v.Patient_ID = p.Patient_ID
WHERE p.Patient_ID IS NULL;  
