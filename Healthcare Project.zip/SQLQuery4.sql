SELECT [Visit_ID]
      ,[Patient_ID]
      ,[Doctor_ID]
      ,[Visit_Date]
      ,[Reason_For_Visit]
      ,[Diagnosis]
      ,[Follow_Up_Required]
      ,[Visit_Type]
      ,[Visit_Status]
  FROM [Healthcare].[dbo].[Visit]


  ----4. Duplicate Records Check

SELECT * 
FROM Visit 
WHERE Visit_ID IN (
    SELECT Visit_ID 
    FROM Visit 
    GROUP BY Visit_ID 
    HAVING COUNT(*) > 1
);

SELECT Visit_ID, COUNT(*) 
FROM Visit 
GROUP BY Visit_ID 
HAVING COUNT(*) > 1;
