SELECT [Visit_ID]
      ,[Patient_ID]
      ,[Doctor_ID]
      ,[Visit_Date]
      ,[Reason_For_Visit]
      ,[Diagnosis]
      ,[Follow_Up_Required]
      ,[Visit_Type]
      ,[Visit_Status]
  FROM [Healthcare].[dbo].[Visit]


  ---- 6. Performance Testing (Query Execution Time)

  SELECT * FROM Visit WHERE Visit_Date BETWEEN '2023-01-01' AND '2023-12-31';