SELECT [Patient_ID]
      ,[Gender]
      ,[Age]
      ,[FirstName]
      ,[LastName]
      ,[BloodType]
      ,[State]
      ,[City]
      ,[Country]
      ,[MedicalHistory]
      ,[MaritalStatus]
  FROM [Healthcare].[dbo].[Patient]

  ----2. Data Completeness Check

SELECT * FROM Patient WHERE FirstName IS NULL OR LastName IS NULL;
SELECT * FROM Visit WHERE Visit_Type IS NULL OR Visit_Date IS NULL;
SELECT * FROM Treatments WHERE Treatment_Name IS NULL OR Status IS NULL;
SELECT * FROM [Lab result] WHERE Test_Name IS NULL OR Result IS NULL;

