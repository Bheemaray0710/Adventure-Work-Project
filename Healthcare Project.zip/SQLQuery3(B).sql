SELECT [Treatment_ID]
      ,[Visit_ID]
      ,[Medication_Prescribed]
      ,[Dosage]
      ,[Instructions]
      ,[Treatment_Cost]
      ,[Treatment_Type]
      ,[Treatment_Name]
      ,[Status]
  FROM [Healthcare].[dbo].[Treatments]

  


  ----3. Data Consistency Check (B)


SELECT t.Treatment_ID, t.Visit_ID, v.Visit_ID
FROM treatments t
LEFT JOIN Visit v ON t.Visit_ID = v.Visit_ID
WHERE v.Visit_ID IS NULL; 
