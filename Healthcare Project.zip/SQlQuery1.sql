SELECT [Patient_ID]
      ,[FirstName]
      ,[LastName]
      ,[Age]
      ,[Gender]
      ,[State]
      ,[Country]
      ,[MedicalHistory]
      ,[MaritalStatus]
      ,[Visit_ID]
      ,[Visit_Date]
      ,[Visit_Type]
      ,[Visit_Status]
      ,[Reason_For_Visit]
      ,[Doctor_ID]
      ,[Doctor_Name]
      ,[Specialty]
      ,[Treatment_ID]
      ,[Treatment_Type]
      ,[Treatment_Name]
      ,[Status]
      ,[Treatment_Cost]
      ,[Lab_Result_ID]
      ,[Test_Name]
      ,[Test_Date]
      ,[Result]
      ,[Normal_Range]
      ,[Units]
  FROM [Healthcare].[dbo].[PatientVisitDetails]


  ----1. Data Count Validation

SELECT 
    COUNT(DISTINCT Patient_ID) AS Total_Patients,
    COUNT(DISTINCT Doctor_ID) AS Total_Doctors,
    COUNT(DISTINCT Visit_ID) AS Total_Visits,
    COUNT(DISTINCT Treatment_ID) AS Total_Treatments,
    COUNT(DISTINCT Lab_Result_ID) AS Total_Lab_Results
FROM PatientVisitDetails;


