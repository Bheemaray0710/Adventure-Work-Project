SELECT 
    patient.Patient_ID,  patient.FirstName, patient.LastName,   patient.Age, patient.Gender,  patient.State, 
    patient.Country,  patient.MedicalHistory,  patient.MaritalStatus,  visit.Visit_ID,  visit.Visit_Date, 
    visit.Visit_Type,  visit.Visit_Status, visit.Reason_For_Visit, doctor.Doctor_ID, doctor.Doctor_Name, 
    doctor.Specialty, treatments.Treatment_ID, treatments.Treatment_Type, treatments.Treatment_Name, 
    treatments.Status, treatments.Treatment_Cost, labresult.Lab_Result_ID, labresult.Test_Name, 
    labresult.Test_Date, labresult.Result, labresult.Normal_Range, labresult.Units
FROM Patient patient
JOIN Visit visit ON patient.Patient_ID = visit.Patient_ID
JOIN Doctor doctor ON visit.Doctor_ID = doctor.Doctor_ID
LEFT JOIN Treatments treatments ON visit.Visit_ID = treatments.Visit_ID
LEFT JOIN [Lab result] labresult ON visit.Visit_ID = labresult.Visit_ID
WHERE 
    patient.Patient_ID IS NOT NULL
    AND visit.Visit_ID IS NOT NULL
    AND doctor.Doctor_ID IS NOT NULL
    AND (treatments.Treatment_ID IS NOT NULL OR labresult.Lab_Result_ID IS NOT NULL)
ORDER BY visit.Visit_Date DESC;
