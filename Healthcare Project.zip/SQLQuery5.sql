SELECT TOP (1000) [Treatment_ID]
      ,[Visit_ID]
      ,[Medication_Prescribed]
      ,[Dosage]
      ,[Instructions]
      ,[Treatment_Cost]
      ,[Treatment_Type]
      ,[Treatment_Name]
      ,[Status]
  FROM [Healthcare].[dbo].[Treatments]


  ----5. Dashboard Aggregation Check
  SELECT 
    (SELECT SUM(Treatment_Cost) FROM Treatments) AS Total_Cost, 
    (SELECT AVG(Age) FROM Patient) AS Avg_Age;
